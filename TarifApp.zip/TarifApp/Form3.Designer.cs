﻿namespace TarifApp
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            panel2 = new Panel();
            button3_1 = new Button();
            groupBox3_1 = new GroupBox();
            listBox1 = new ListBox();
            label3_1 = new Label();
            toolTip3_1 = new ToolTip(components);
            panel2.SuspendLayout();
            groupBox3_1.SuspendLayout();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = Color.DarkCyan;
            panel2.Controls.Add(button3_1);
            panel2.Controls.Add(groupBox3_1);
            panel2.Controls.Add(label3_1);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(810, 534);
            panel2.TabIndex = 1;
            // 
            // button3_1
            // 
            button3_1.BackColor = Color.Red;
            button3_1.Font = new Font("Trebuchet MS", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 162);
            button3_1.Location = new Point(350, 481);
            button3_1.Name = "button3_1";
            button3_1.Size = new Size(90, 41);
            button3_1.TabIndex = 2;
            button3_1.Text = "TARİF SİL";
            toolTip3_1.SetToolTip(button3_1, "Bu butona basmak, seçtiğiniz tarif ve ona ait tüm içeriği kalıcı olarak silecektir.");
            button3_1.UseVisualStyleBackColor = false;
            button3_1.Click += button1_Click;
            // 
            // groupBox3_1
            // 
            groupBox3_1.Controls.Add(listBox1);
            groupBox3_1.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox3_1.Location = new Point(60, 39);
            groupBox3_1.Name = "groupBox3_1";
            groupBox3_1.Size = new Size(680, 436);
            groupBox3_1.TabIndex = 1;
            groupBox3_1.TabStop = false;
            groupBox3_1.Text = "TARİFLER";
            groupBox3_1.Enter += groupBox3_1_Enter;
            // 
            // listBox1
            // 
            listBox1.BackColor = Color.LightGray;
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 19;
            listBox1.Location = new Point(3, 22);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(671, 403);
            listBox1.TabIndex = 0;
            // 
            // label3_1
            // 
            label3_1.AutoSize = true;
            label3_1.Font = new Font("Trebuchet MS", 9.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 162);
            label3_1.Location = new Point(285, 18);
            label3_1.Name = "label3_1";
            label3_1.Size = new Size(203, 18);
            label3_1.TabIndex = 0;
            label3_1.Text = "Silmek istediğiniz tarifi seçiniz:";
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(810, 534);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "Form3";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Tarif Sil";
            Load += Form3_Load;
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            groupBox3_1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private Panel panel2;
        private GroupBox groupBox3_1;
        private Label label3_1;
        private ListBox listBox1;
        private Button button3_1;
        private ToolTip toolTip3_1;
    }
}