﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Text.RegularExpressions;

namespace TarifApp.Data

{
    public class Data
    {
        private const string server = "localhost";
        private const string database = "myDB";
        private const string userID = "root";
        private const string password = "root";
        private readonly string connectionString;

        public Data()
        {
            connectionString = $"Server={server};Database={database};User ID={userID};Password={password};";
        }
        public decimal GetRecipeCost(string tarifAdi)
        {
            decimal toplamMaliyet = 0;

            using (MySqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();

                    // TarifID'yi al
                    string getTarifIdQuery = "SELECT TarifID FROM tarif WHERE TarifAdi = @tarifAdi";
                    int tarifID = 0;
                    using (MySqlCommand command = new MySqlCommand(getTarifIdQuery, connection))
                    {
                        command.Parameters.AddWithValue("@tarifAdi", tarifAdi);
                        tarifID = Convert.ToInt32(command.ExecuteScalar());
                    }

                    // MalzemeMiktar ve BirimFiyat ile maliyeti hesapla
                    string getCostQuery = @"
                SELECT tmi.MalzemeMiktar, m.BirimFiyat 
                FROM tarif_malzeme_iliski tmi
                INNER JOIN malzemeler m ON tmi.MalzemeID = m.MalzemeID
                WHERE tmi.TarifID = @tarifID";

                    using (MySqlCommand command = new MySqlCommand(getCostQuery, connection))
                    {
                        command.Parameters.AddWithValue("@tarifID", tarifID);
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                decimal malzemeMiktar = reader.GetDecimal("MalzemeMiktar");
                                decimal birimFiyat = reader.GetDecimal("BirimFiyat");
                                toplamMaliyet += malzemeMiktar * birimFiyat;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }

            return toplamMaliyet;
        }


        private MySqlConnection GetConnection()
        {
            return new MySqlConnection(connectionString);
        }
        public List<string> GetDataForListBox(string searchText)
        {
            List<string> results = new List<string>();

            using (MySqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();

                    // Tarif adları, hazırlama süresi, kategori adı ve maliyet bilgisi için sorgu
                    string query = @"
                SELECT Tarif.TarifAdi, Tarif.HazirlamaSuresi, Kategori.KategoriAdi 
                FROM Tarif 
                JOIN Kategoriler Kategori ON Tarif.KategoriID = Kategori.KategoriID 
                WHERE Tarif.TarifAdi LIKE @searchText";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@searchText", $"%{searchText}%");
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string tarifAdi = reader["TarifAdi"].ToString();
                                int hazirlamaSuresi = Convert.ToInt32(reader["HazirlamaSuresi"]);
                                string kategoriAdi = reader["KategoriAdi"].ToString();
                                decimal maliyet = GetRecipeCost(tarifAdi);

                                // Sonuçları biçimlendirme ve ekleme
                                string result = $"{tarifAdi} - Kategori: {kategoriAdi} - Süre: {hazirlamaSuresi} dk - Maliyet: {maliyet:C}";
                                results.Add(result);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }

            return results;
        }

        // Süreyi Ayıklayan Fonksiyon
        public static int ExtractTime(string result)
        {
            // "Süre: " ifadesinden sonra gelen sayıyı bulmak için regex deseni
            string pattern = @"Süre:\s*(\d+)\s*dk";
            Match match = Regex.Match(result, pattern);

            if (match.Success)
            {
                // İlk yakalanan grubu (süre değerini) alıyoruz
                if (int.TryParse(match.Groups[1].Value, out int time))
                {
                    return time;
                }
            }
            return 0; // Süre bulunamazsa varsayılan değer
        }

        // Maliyeti Ayıklayan Fonksiyon
        public static decimal ExtractCost(string result)
        {
            // "Maliyet: $" ifadesinden sonra gelen sayıyı bulmak için regex deseni
            string pattern = @"Maliyet: \$\s*(\d+(\.\d{1,2})?)";
            Match match = Regex.Match(result, pattern);

            if (match.Success)
            {
                // İlk yakalanan grubu (maliyet değerini) alıyoruz
                if (decimal.TryParse(match.Groups[1].Value, out decimal cost))
                {
                    return cost;
                }
            }
            return 0.0m; // Maliyet bulunamazsa varsayılan değer
        }
        public string ExtractTarifAdi(string item)
        {
            // Eğer ListBox'taki format şu şekildeyse: "Tarif Adı - Kategori: XYZ - Süre: X dk - Maliyet: X"
            return item.Split('-')[0].Trim();
        }
        public int GetMalzemeCountByTarifID(int tarifID)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM tarif_malzeme_iliski WHERE TarifID = @TarifID";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@TarifID", tarifID);

                var result = command.ExecuteScalar();
                if (result != null)
                {
                    return Convert.ToInt32(result);
                }
                return 0; // Eğer malzeme ilişkisi yoksa 0 döner
            }
        }
        public int GetTarifIDByName(string tarifAdi)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT TarifID FROM tarif WHERE TarifAdi = @TarifAdi";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@TarifAdi", tarifAdi);

                var result = command.ExecuteScalar();
                if (result != null)
                {
                    return Convert.ToInt32(result);
                }
                return -1; // Eğer tarif bulunamazsa -1 döner
            }
        }


        public List<int> GetMalzemeIDsByTarifID(int tarifID)
        {
            List<int> malzemeIDs = new List<int>();

            using (MySqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    string query = "SELECT MalzemeID FROM tarif_malzeme_iliski WHERE TarifID = @tarifID";
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@tarifID", tarifID);

                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                malzemeIDs.Add(Convert.ToInt32(reader["MalzemeID"]));
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }

            return malzemeIDs;
        }


        public List<string> GetData(string query, MySqlParameter[] parameters)
        {
            List<string> results = new List<string>();

            using (MySqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        if (parameters != null)
                        {
                            command.Parameters.AddRange(parameters);
                        }
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                results.Add(reader["TarifAdi"].ToString());
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }

            return results;
        }
        public void AddTarifWithMalzemeler(string tarifAdi, int kategoriID, int hazirlamaSuresi, string talimatlar, List<(string malzemeAdi, int malzemeMiktar)> malzemeler)
        {
            using (MySqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();

                    // 1. Tarif Tablosuna Yeni Tarif Ekleme
                    string insertTarifQuery = "INSERT INTO tarif (TarifID, TarifAdi, KategoriID, HazirlamaSuresi, Talimatlar) " +
                                              "VALUES (@tarifID, @tarifAdi, @kategoriID, @hazirlamaSuresi, @talimatlar)";

                    // TarifID'yi otomatik oluşturmak için max TarifID'yi bul ve 1 ekle
                    string selectMaxTarifIDQuery = "SELECT IFNULL(MAX(TarifID), 0) + 1 FROM tarif";
                    MySqlCommand selectMaxTarifIDCmd = new MySqlCommand(selectMaxTarifIDQuery, connection);
                    int tarifID = Convert.ToInt32(selectMaxTarifIDCmd.ExecuteScalar());

                    // Tarif ekleme komutunu hazırla
                    MySqlCommand insertTarifCmd = new MySqlCommand(insertTarifQuery, connection);
                    insertTarifCmd.Parameters.AddWithValue("@tarifID", tarifID);
                    insertTarifCmd.Parameters.AddWithValue("@tarifAdi", tarifAdi);
                    insertTarifCmd.Parameters.AddWithValue("@kategoriID", kategoriID);
                    insertTarifCmd.Parameters.AddWithValue("@hazirlamaSuresi", hazirlamaSuresi);
                    insertTarifCmd.Parameters.AddWithValue("@talimatlar", talimatlar);
                    insertTarifCmd.ExecuteNonQuery();

                    // 2. Her Malzeme için `tarif_malzeme_iliskisi` Tablosunu Güncelleme
                    foreach (var (malzemeAdi, malzemeMiktar) in malzemeler)
                    {
                        // MalzemeID'yi bul veya oluştur
                        string selectMalzemeIDQuery = "SELECT MalzemeID FROM malzemeler WHERE MalzemeAdi = @malzemeAdi";
                        MySqlCommand selectMalzemeIDCmd = new MySqlCommand(selectMalzemeIDQuery, connection);
                        selectMalzemeIDCmd.Parameters.AddWithValue("@malzemeAdi", malzemeAdi);

                        object malzemeIDObj = selectMalzemeIDCmd.ExecuteScalar();
                        int malzemeID;

                        if (malzemeIDObj == null)
                        {
                            // MalzemeID yoksa yeni malzeme ekle ve MalzemeID'yi al
                            string insertMalzemeQuery = "INSERT INTO malzemeler (MalzemeID, MalzemeAdi) VALUES (@malzemeID, @malzemeAdi)";

                            // MalzemeID'yi oluşturmak için max MalzemeID'yi bul ve 1 ekle
                            string selectMaxMalzemeIDQuery = "SELECT IFNULL(MAX(MalzemeID), 0) + 1 FROM malzemeler";
                            MySqlCommand selectMaxMalzemeIDCmd = new MySqlCommand(selectMaxMalzemeIDQuery, connection);
                            malzemeID = Convert.ToInt32(selectMaxMalzemeIDCmd.ExecuteScalar());

                            MySqlCommand insertMalzemeCmd = new MySqlCommand(insertMalzemeQuery, connection);
                            insertMalzemeCmd.Parameters.AddWithValue("@malzemeID", malzemeID);
                            insertMalzemeCmd.Parameters.AddWithValue("@malzemeAdi", malzemeAdi);
                            insertMalzemeCmd.ExecuteNonQuery();
                        }
                        else
                        {
                            // MalzemeID mevcutsa onu kullan
                            malzemeID = Convert.ToInt32(malzemeIDObj);
                        }

                        // tarif_malzeme_iliskisi tablosuna malzeme ekleme
                        string insertIliskiQuery = "INSERT INTO tarif_malzeme_iliskisi (TarifID, MalzemeID, MalzemeMiktar) " +
                                                   "VALUES (@tarifID, @malzemeID, @malzemeMiktar)";
                        MySqlCommand insertIliskiCmd = new MySqlCommand(insertIliskiQuery, connection);
                        insertIliskiCmd.Parameters.AddWithValue("@tarifID", tarifID);
                        insertIliskiCmd.Parameters.AddWithValue("@malzemeID", malzemeID);
                        insertIliskiCmd.Parameters.AddWithValue("@malzemeMiktar", malzemeMiktar);                        insertIliskiCmd.Parameters.AddWithValue("@kategoriID", kategoriID);
                        insertIliskiCmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }
        }
        public int GetMalzemeIDByName(string malzemeAdi)
        {
            int malzemeID = 0;

            using (MySqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    string query = "SELECT MalzemeID FROM malzemeler WHERE MalzemeAdi = @malzemeAdi";
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@malzemeAdi", malzemeAdi);

                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                malzemeID = Convert.ToInt32(reader["MalzemeID"]);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }

            return malzemeID;
        }

        public List<string> GetMalzemeler()
        {
            List<string> malzemeler = new List<string>();

            using (MySqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();

                    // Malzemeleri çekmek için SQL sorgusu
                    string query = "SELECT MalzemeAdi FROM malzemeler";
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                malzemeler.Add(reader["MalzemeAdi"].ToString());
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }

            return malzemeler;
        }



        public List<string> GetDataMessageBox(string query, MySqlParameter[] parameters)
        {
            List<string> results = new List<string>();

            using (MySqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        if (parameters != null)
                        {
                            command.Parameters.AddRange(parameters);
                        }
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                // Her bir sütunu sırayla ekle
                                results.Add(reader["HazirlamaSuresi"].ToString());
                                results.Add(reader["Talimatlar"].ToString());
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }

            return results;
        }
        public List<string> GetAllTarifAdlari()
        {
            List<string> tarifAdlari = new List<string>();
            using (MySqlConnection conn = GetConnection())
            {
                conn.Open();
                string query = "SELECT TarifAdi FROM tarif";
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            tarifAdlari.Add(reader["TarifAdi"].ToString());
                        }
                    }
                }
            }
            return tarifAdlari;
        }
        public void DeleteTarifMalzemeIliskiByTarifID(int tarifID)
        {
            using (MySqlConnection conn = GetConnection())
            {
                conn.Open();
                string query = "DELETE FROM tarif_malzeme_iliski WHERE TarifID = @TarifID";
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@TarifID", tarifID);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        public void DeleteTarifByTarifID(int tarifID)
        {
            using (MySqlConnection conn = GetConnection())
            {
                conn.Open();
                string query = "DELETE FROM tarif WHERE TarifID = @TarifID";
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@TarifID", tarifID);
                    cmd.ExecuteNonQuery();
                }
            }
        }




    }
}

