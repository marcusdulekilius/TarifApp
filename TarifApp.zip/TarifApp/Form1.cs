﻿using MySql.Data.MySqlClient;

namespace TarifApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Data.Data data = new Data.Data();

            comboBox1_1.DropDownStyle = ComboBoxStyle.DropDownList;

            // Malzemeleri al
            List<string> malzemeler = data.GetMalzemeler();
            listBox1_1.DrawMode = DrawMode.OwnerDrawFixed;
            listBox1_1.DrawItem += new DrawItemEventHandler(listBox1_1_DrawItem);

            // Malzemeleri checkedListBox1_1 içerisine ekle
            checkedListBox1_1.Items.AddRange(malzemeler.ToArray());

            // Tüm tarifleri yükle ve ListBox'a ekle
            LoadAllTarifler();
        }

        private void LoadAllTarifler()
        {
            var data = new Data.Data();
            string query = "SELECT TarifAdi FROM Tarif"; // Tüm tarifleri almak için sorgu
            var results = data.GetData(query, null); // Parametre yoksa null gönder

            listBox1_1.Items.Clear(); // Önceki sonuçları temizle

            // Tüm tarifleri ListBox'a ekle
            foreach (var result in results)
            {
                listBox1_1.Items.Add(result);
            }
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string searchText = textBox1_1.Text;
            var data = new Data.Data();

            // Verileri al
            var results = data.GetDataForListBox(searchText);

            string selectedOrder = comboBox1_1.SelectedItem?.ToString();
            if (selectedOrder == "Önce Ucuz")
            {
                results = results.OrderBy(r => Data.Data.ExtractCost(r)).ToList(); // Maliyete göre artan sırayla
            }
            else if (selectedOrder == "Önce Pahalı")
            {
                results = results.OrderByDescending(r => Data.Data.ExtractCost(r)).ToList(); // Maliyete göre azalan sırayla
            }
            else if (selectedOrder == "Önce Hızlı")
            {
                results = results.OrderBy(r => Data.Data.ExtractTime(r)).ToList(); // Süreye göre artan sırayla
            }
            else if (selectedOrder == "Önce Yavaş")
            {
                results = results.OrderByDescending(r => Data.Data.ExtractTime(r)).ToList(); // Süreye göre azalan sırayla
            }
            else if (selectedOrder == "Önce Az Malzemeli")
            {
                // Az malzemeli olanları bulmak için malzeme sayısına göre sıralama
                results = results.OrderBy(r =>
                {
                    string tarifAdi = data.ExtractTarifAdi(r); // Tarif adını ayıklama fonksiyonu
                    int tarifID = data.GetTarifIDByName(tarifAdi); // TarifID'yi bul
                    return data.GetMalzemeCountByTarifID(tarifID); // Malzeme sayısına göre sıralama
                }).ToList();
            }
            else if (selectedOrder == "Önce Çok Malzemeli")
            {
                // Çok malzemeli olanları bulmak için malzeme sayısına göre azalan sırayla sıralama
                results = results.OrderByDescending(r =>
                {
                    string tarifAdi = data.ExtractTarifAdi(r); // Tarif adını ayıklama fonksiyonu
                    int tarifID = data.GetTarifIDByName(tarifAdi); // TarifID'yi bul
                    return data.GetMalzemeCountByTarifID(tarifID); // Malzeme sayısına göre sıralama
                }).ToList();
            }

            listBox1_1.Items.Clear(); // Önceki sonuçları temizle

            // Sıralanmış sonuçları ListBox'a ekle
            foreach (var result in results)
            {
                listBox1_1.Items.Add(result);
            }
        }

        private void Ara_Click(object sender, EventArgs e)
        {
            string searchText = textBox1_1.Text;
            var data = new Data.Data();

            string query = "SELECT TarifAdi FROM Tarif WHERE TarifAdi LIKE @searchText";
            var parameters = new MySqlParameter[]
            {
                new MySqlParameter("@searchText", $"%{searchText}%")
            };

            var results = data.GetData(query, parameters);

            foreach (var result in results)
            {

                Console.WriteLine(result);
                MessageBox.Show($"Tarif Adı: {result}");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }
        public void SortListBoxByMalzemeCount()
        {
            var data = new Data.Data();
            // ListBox öğelerini bir listeye al
            List<string> items = new List<string>();
            foreach (string item in listBox1_1.Items)
            {
                items.Add(item);
            }

            // Tarifler ve malzeme sayıları için bir liste oluştur
            List<Tuple<string, int>> tariflerMalzemeCount = new List<Tuple<string, int>>();

            foreach (var item in items)
            {
                string tarifAdi = data.ExtractTarifAdi(item); // Tarif adını ayıklama fonksiyonu
                int tarifID = data.GetTarifIDByName(tarifAdi);
                if (tarifID != -1)
                {
                    int malzemeCount = data.GetMalzemeCountByTarifID(tarifID);
                    tariflerMalzemeCount.Add(new Tuple<string, int>(item, malzemeCount));
                }
            }

            // Malzeme sayısına göre sıralama yap (en çok malzemesi olanlar en üste)
            tariflerMalzemeCount = tariflerMalzemeCount.OrderByDescending(x => x.Item2).ToList();

            // ListBox'ı temizleyip sıralanmış öğeleri ekle
            listBox1_1.Items.Clear();
            foreach (var tarif in tariflerMalzemeCount)
            {
                listBox1_1.Items.Add(tarif.Item1); // Sadece tarif adını ekle
            }
        }

        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (listBox1_1.SelectedItem != null)
            {
                string selectedTarif = listBox1_1.SelectedItem.ToString();
                var data = new Data.Data();

                // Veritabanından HazirlamaSuresi ve Talimatlari alıyoruz
                string query = "SELECT HazirlamaSuresi, Talimatlar FROM Tarif WHERE TarifAdi = @tarifAdi";
                var parameters = new MySqlParameter[]
                {
     new MySqlParameter("@tarifAdi", selectedTarif)
                };

                // GetData fonksiyonunu kullanarak HazirlamaSuresi ve Talimatlari alalım
                List<string> result = data.GetDataMessageBox(query, parameters);

                // Sonuçları kontrol et
                if (result.Count == 0)
                {
                    // Eğer sonuç yoksa, kullanıcıya bilgi ver
                    MessageBox.Show("Seçilen tarif ile ilgili detay bulunamadı.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; // Fonksiyondan çık
                }

                // Sonuç varsa, bilgileri al ve MessageBox'ı göster
                string hazirlamaSuresi = result[0];  // HazirlamaSuresi
                string talimatlari = result[1];      // Talimatlari

                // MessageBox ile tarif detaylarını göster
                string message = $"Hazırlama Süresi: {hazirlamaSuresi} dakika\nTalimatlar: {talimatlari}";
                MessageBox.Show(message, $"{selectedTarif} Tarifi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        private void button1_2_Click(object sender, EventArgs e)
        {
            // Form2'yi oluştur
            Form2 form2 = new Form2();

            // Form2'yi göster
            form2.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            comboBox1_1.DroppedDown = true;
        }

        private void comboBox1_1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_3_Click(object sender, EventArgs e)
        {
            // Form3'ü oluştur
            Form3 form3 = new Form3();

            // Form3'ü göster
            form3.Show();
        }

        private void button1_4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void checkedListBox1_1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_1_CheckedChanged(object sender, EventArgs e)
        {
            listBox1_1.Invalidate(); // ListBox'ı yeniden çiz
        }

        private void groupBox1_1_Enter(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void checkBox1_1_CheckedChanged_1(object sender, EventArgs e)
        {

        }


        private void listBox1_1_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0)
                return;

            // Eğer checkBox1_1 işaretli değilse, varsayılan renkte çiz
            if (!checkBox1_1.Checked)
            {
                e.DrawBackground();
                e.Graphics.DrawString(listBox1_1.Items[e.Index].ToString(), e.Font, Brushes.Black, e.Bounds);
                e.DrawFocusRectangle();
                return;
            }

            Data.Data data = new Data.Data();
            string tarifItem = listBox1_1.Items[e.Index].ToString();
            string tarifAdi = data.ExtractTarifAdi(tarifItem);
            int tarifID = data.GetTarifIDByName(tarifAdi);
            List<int> tarifMalzemeIDs = data.GetMalzemeIDsByTarifID(tarifID);
            List<int> selectedMalzemeIDs = GetSelectedMalzemeIDs();

            // Hiç malzeme seçilmemişse, tüm tarifleri yeşil yap
            if (selectedMalzemeIDs.Count == 0)
            {
                e.DrawBackground();
                e.Graphics.DrawString(listBox1_1.Items[e.Index].ToString(), e.Font, Brushes.Green, e.Bounds);
                e.DrawFocusRectangle();
                return;
            }

            // Tarif malzemeleri seçilen malzemeleri kapsıyor mu kontrol et
            bool allIngredientsMatch = TarifMalzemeleriCheckedListBoxMalzemeleriKapsıyor(tarifMalzemeIDs, selectedMalzemeIDs);

            // Malzemelere göre yeşil ya da kırmızı renkte çiz
            Color textColor = allIngredientsMatch ? Color.Green : Color.Red;

            e.DrawBackground();
            using (SolidBrush brush = new SolidBrush(textColor))
            {
                e.Graphics.DrawString(listBox1_1.Items[e.Index].ToString(), e.Font, brush, e.Bounds);
            }

            e.DrawFocusRectangle();
        }

        // Tarif malzemelerinin seçilen malzemeleri kapsayıp kapsamadığını kontrol eden fonksiyon
        private bool TarifMalzemeleriCheckedListBoxMalzemeleriKapsıyor(List<int> tarifMalzemeIDs, List<int> selectedMalzemeIDs)
        {
            return !tarifMalzemeIDs.Except(selectedMalzemeIDs).Any();
        }


        // Bu fonksiyon, tarifin tüm malzemelerinin seçili malzemelerle eşleşip eşleşmediğini kontrol eder.


        private List<int> GetSelectedMalzemeIDs()
        {
            List<int> selectedMalzemeIDs = new List<int>();

            // Tüm CheckedItems üzerinden geçip her seçili öğenin ID'sini al
            foreach (var selectedItem in checkedListBox1_1.CheckedItems)
            {
                // Seçilen malzemenin adını al (varsayılan olarak CheckedListBox'a isim ekleniyor)
                string malzemeAdi = selectedItem.ToString();

                // Malzemenin ID'sini veritabanından al (malzeme adıyla)
                var data = new Data.Data();
                int malzemeID = data.GetMalzemeIDByName(malzemeAdi);

                // ID'yi listeye ekle
                selectedMalzemeIDs.Add(malzemeID);
            }

            return selectedMalzemeIDs;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            // Form3'ü oluştur
            Form4 form4 = new Form4();

            // Form3'ü göster
            form4.Show();
        }
    }
}
