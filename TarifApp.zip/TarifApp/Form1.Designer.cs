﻿namespace TarifApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            button1_1 = new Button();
            comboBox1_1 = new ComboBox();
            groupBox1_1 = new GroupBox();
            listBox1_1 = new ListBox();
            textBox1_1 = new TextBox();
            button1_6 = new Button();
            panel1 = new Panel();
            checkBox1_1 = new CheckBox();
            toolTip1_3 = new ToolTip(components);
            button1_5 = new Button();
            toolTip1_1 = new ToolTip(components);
            button1_2 = new Button();
            toolTip1_2 = new ToolTip(components);
            button1_3 = new Button();
            toolTip1_4 = new ToolTip(components);
            toolTip1_5 = new ToolTip(components);
            label1_1 = new Label();
            toolTip1_6 = new ToolTip(components);
            checkedListBox1_1 = new CheckedListBox();
            panel1_2 = new Panel();
            label1_2 = new Label();
            panel1_1 = new Panel();
            button1_4 = new Button();
            toolTip1_7 = new ToolTip(components);
            toolTip1_8 = new ToolTip(components);
            groupBox1_1.SuspendLayout();
            panel1.SuspendLayout();
            panel1_2.SuspendLayout();
            panel1_1.SuspendLayout();
            SuspendLayout();
            // 
            // button1_1
            // 
            button1_1.Anchor = AnchorStyles.Top;
            button1_1.BackColor = Color.CadetBlue;
            button1_1.BackgroundImage = Properties.Resources.search;
            button1_1.BackgroundImageLayout = ImageLayout.None;
            button1_1.Font = new Font("Arial Narrow", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button1_1.ForeColor = Color.CadetBlue;
            button1_1.Image = Properties.Resources.search;
            button1_1.Location = new Point(848, 13);
            button1_1.Name = "button1_1";
            button1_1.Size = new Size(54, 54);
            button1_1.TabIndex = 1;
            button1_1.Text = "\r\n";
            button1_1.UseVisualStyleBackColor = false;
            button1_1.Click += Ara_Click;
            // 
            // comboBox1_1
            // 
            comboBox1_1.Anchor = AnchorStyles.Top;
            comboBox1_1.BackColor = Color.PaleTurquoise;
            comboBox1_1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1_1.FormattingEnabled = true;
            comboBox1_1.Items.AddRange(new object[] { "Önce Ucuz", "Önce Pahalı", "Önce Hızlı", "Önce Yavaş", "Önce Az Malzemeli", "Önce Çok Malzemeli" });
            comboBox1_1.Location = new Point(276, 41);
            comboBox1_1.Name = "comboBox1_1";
            comboBox1_1.Size = new Size(110, 23);
            comboBox1_1.TabIndex = 3;
            comboBox1_1.Visible = false;
            // 
            // groupBox1_1
            // 
            groupBox1_1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            groupBox1_1.AutoSize = true;
            groupBox1_1.BackColor = Color.SteelBlue;
            groupBox1_1.Controls.Add(listBox1_1);
            groupBox1_1.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox1_1.ForeColor = SystemColors.InactiveCaptionText;
            groupBox1_1.Location = new Point(262, 102);
            groupBox1_1.Name = "groupBox1_1";
            groupBox1_1.Size = new Size(725, 427);
            groupBox1_1.TabIndex = 5;
            groupBox1_1.TabStop = false;
            groupBox1_1.Text = "TARİFLER";
            groupBox1_1.Enter += groupBox1_1_Enter;
            // 
            // listBox1_1
            // 
            listBox1_1.BackColor = Color.SteelBlue;
            listBox1_1.Dock = DockStyle.Fill;
            listBox1_1.DrawMode = DrawMode.OwnerDrawFixed;
            listBox1_1.FormattingEnabled = true;
            listBox1_1.ItemHeight = 60;
            listBox1_1.Location = new Point(3, 22);
            listBox1_1.Name = "listBox1_1";
            listBox1_1.Size = new Size(719, 402);
            listBox1_1.TabIndex = 0;
            listBox1_1.SelectedIndexChanged += listBox1_SelectedIndexChanged_1;
            // 
            // textBox1_1
            // 
            textBox1_1.Cursor = Cursors.IBeam;
            textBox1_1.Location = new Point(405, 30);
            textBox1_1.Name = "textBox1_1";
            textBox1_1.Size = new Size(409, 23);
            textBox1_1.TabIndex = 0;
            textBox1_1.TextChanged += textBox1_TextChanged;
            // 
            // button1_6
            // 
            button1_6.BackColor = Color.CadetBlue;
            button1_6.Image = Properties.Resources.Sorting_arrowheads;
            button1_6.Location = new Point(307, 9);
            button1_6.Name = "button1_6";
            button1_6.Size = new Size(54, 54);
            button1_6.TabIndex = 7;
            button1_6.UseVisualStyleBackColor = false;
            button1_6.Click += button5_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.CadetBlue;
            panel1.Controls.Add(checkBox1_1);
            panel1.Controls.Add(button1_6);
            panel1.Controls.Add(comboBox1_1);
            panel1.Controls.Add(button1_1);
            panel1.Controls.Add(textBox1_1);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1108, 561);
            panel1.TabIndex = 8;
            panel1.Paint += panel1_Paint;
            // 
            // checkBox1_1
            // 
            checkBox1_1.Font = new Font("Trebuchet MS", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            checkBox1_1.Location = new Point(935, 22);
            checkBox1_1.Name = "checkBox1_1";
            checkBox1_1.Size = new Size(107, 42);
            checkBox1_1.TabIndex = 0;
            checkBox1_1.Text = "Tarif Önerisi";
            toolTip1_4.SetToolTip(checkBox1_1, "Aktif edildiğinde, yapabileceğiniz yemekler yeşil, yapamayacağınız yemekler kırmızı olarak listelenir.");
            checkBox1_1.UseVisualStyleBackColor = true;
            checkBox1_1.CheckedChanged += checkBox1_1_CheckedChanged_1;
            // 
            // button1_5
            // 
            button1_5.Font = new Font("Trebuchet MS", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1_5.Image = (Image)resources.GetObject("button1_5.Image");
            button1_5.ImageAlign = ContentAlignment.MiddleLeft;
            button1_5.Location = new Point(10, 215);
            button1_5.Name = "button1_5";
            button1_5.Size = new Size(168, 49);
            button1_5.TabIndex = 4;
            button1_5.Text = "Rastgele";
            toolTip1_3.SetToolTip(button1_5, "Ne yapacağına karar veremedin mi? Haydi rastgele :)\r\n");
            button1_5.UseVisualStyleBackColor = true;
            // 
            // button1_2
            // 
            button1_2.Font = new Font("Trebuchet MS", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 162);
            button1_2.Image = (Image)resources.GetObject("button1_2.Image");
            button1_2.ImageAlign = ContentAlignment.MiddleLeft;
            button1_2.Location = new Point(10, 51);
            button1_2.Name = "button1_2";
            button1_2.Size = new Size(168, 49);
            button1_2.TabIndex = 0;
            button1_2.Text = "Tarif Ekle";
            toolTip1_1.SetToolTip(button1_2, "Sizi tarif ekleyebileceğiniz bir pencereye yönlendirir.");
            button1_2.UseVisualStyleBackColor = true;
            button1_2.Click += button1_2_Click;
            // 
            // button1_3
            // 
            button1_3.Font = new Font("Trebuchet MS", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 162);
            button1_3.Image = (Image)resources.GetObject("button1_3.Image");
            button1_3.ImageAlign = ContentAlignment.MiddleLeft;
            button1_3.Location = new Point(10, 106);
            button1_3.Name = "button1_3";
            button1_3.Size = new Size(168, 49);
            button1_3.TabIndex = 3;
            button1_3.Text = "Tarif Sil";
            toolTip1_2.SetToolTip(button1_3, "Sizi tarif ekleyebileceğiniz bir pencereye yönlendirir.");
            button1_3.UseVisualStyleBackColor = true;
            button1_3.Click += button1_3_Click;
            // 
            // label1_1
            // 
            label1_1.Anchor = AnchorStyles.Top;
            label1_1.AutoSize = true;
            label1_1.Cursor = Cursors.No;
            label1_1.Font = new Font("Times New Roman", 11.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1_1.Location = new Point(36, 9);
            label1_1.Name = "label1_1";
            label1_1.Size = new Size(112, 18);
            label1_1.TabIndex = 2;
            label1_1.Text = "Nefisito Lezizani";
            toolTip1_5.SetToolTip(label1_1, "Koperniik Pizzasıı GALAKSİNİN ENN SICAK PİİİİİZZASI PİİİİZZASI");
            label1_1.Click += label1_Click;
            // 
            // checkedListBox1_1
            // 
            checkedListBox1_1.BackColor = Color.CornflowerBlue;
            checkedListBox1_1.CheckOnClick = true;
            checkedListBox1_1.FormattingEnabled = true;
            checkedListBox1_1.Location = new Point(12, 311);
            checkedListBox1_1.Name = "checkedListBox1_1";
            checkedListBox1_1.ScrollAlwaysVisible = true;
            checkedListBox1_1.Size = new Size(167, 238);
            checkedListBox1_1.Sorted = true;
            checkedListBox1_1.TabIndex = 8;
            checkedListBox1_1.SelectedIndexChanged += checkedListBox1_1_SelectedIndexChanged_1;
            // 
            // panel1_2
            // 
            panel1_2.BackColor = Color.MediumSlateBlue;
            panel1_2.Controls.Add(checkedListBox1_1);
            panel1_2.Controls.Add(label1_2);
            panel1_2.Controls.Add(panel1_1);
            panel1_2.Dock = DockStyle.Left;
            panel1_2.Location = new Point(0, 0);
            panel1_2.Name = "panel1_2";
            panel1_2.Size = new Size(192, 561);
            panel1_2.TabIndex = 6;
            // 
            // label1_2
            // 
            label1_2.AutoSize = true;
            label1_2.Font = new Font("Trebuchet MS", 9.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 162);
            label1_2.Location = new Point(12, 281);
            label1_2.Name = "label1_2";
            label1_2.Size = new Size(154, 18);
            label1_2.TabIndex = 2;
            label1_2.Text = "Malzemeye Göre Arama";
            toolTip1_7.SetToolTip(label1_2, "Elinizde mevcut olan malzemeleri burada işaretleyin, sizler için yapabileceğiniz yemekleri listeleyeceğiz.\r\n");
            // 
            // panel1_1
            // 
            panel1_1.Controls.Add(button1_4);
            panel1_1.Controls.Add(button1_5);
            panel1_1.Controls.Add(button1_3);
            panel1_1.Controls.Add(button1_2);
            panel1_1.Controls.Add(label1_1);
            panel1_1.Dock = DockStyle.Top;
            panel1_1.Location = new Point(0, 0);
            panel1_1.Name = "panel1_1";
            panel1_1.Size = new Size(192, 278);
            panel1_1.TabIndex = 7;
            // 
            // button1_4
            // 
            button1_4.Font = new Font("Trebuchet MS", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 162);
            button1_4.Image = Properties.Resources.Update2;
            button1_4.ImageAlign = ContentAlignment.MiddleLeft;
            button1_4.Location = new Point(11, 161);
            button1_4.Name = "button1_4";
            button1_4.Size = new Size(167, 48);
            button1_4.TabIndex = 5;
            button1_4.Text = "Güncelle";
            toolTip1_8.SetToolTip(button1_4, "Sizi listelenen tariflerden istediğinizi güncelleyebileceğiniz bir ekrana götürür.");
            button1_4.UseVisualStyleBackColor = true;
            button1_4.Click += button1_Click_1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MediumOrchid;
            ClientSize = new Size(1108, 561);
            Controls.Add(panel1_2);
            Controls.Add(groupBox1_1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Nefisito Lezizani";
            Load += Form1_Load;
            groupBox1_1.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel1_2.ResumeLayout(false);
            panel1_2.PerformLayout();
            panel1_1.ResumeLayout(false);
            panel1_1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button1_1;
        private ComboBox comboBox1_1;
        private GroupBox groupBox1_1;
        private TextBox textBox1_1;
        private ListBox listBox1_1;
        private Button button1_6;
        private Panel panel1;
        private CheckBox checkBox1_1;
        private ToolTip toolTip1_3;
        private ToolTip toolTip1_1;
        private ToolTip toolTip1_2;
        private ToolTip toolTip1_4;
        private ToolTip toolTip1_5;
        private ToolTip toolTip1_6;
        private CheckedListBox checkedListBox1_1;
        private Panel panel1_2;
        private Panel panel1_1;
        private Button button1_5;
        private Button button1_3;
        private Button button1_2;
        private Label label1_1;
        private Label label1_2;
        private ToolTip toolTip1_7;
        private Button button1_4;
        private ToolTip toolTip1_8;
    }
}
