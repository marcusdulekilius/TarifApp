﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TarifApp
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void groupBox3_1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null)
            {
                MessageBox.Show("Lütfen bir tarif seçin.");
                return;
            }

            // Seçilen tarifin adını al
            string selectedTarifAdi = listBox1.SelectedItem.ToString();

            // Data sınıfı ile TarifID'yi bul
            Data.Data data = new Data.Data();
            int tarifID = data.GetTarifIDByName(selectedTarifAdi); // TarifAdı ile TarifID'yi bulma fonksiyonu

            if (tarifID > 0)
            {
                // TarifID ile tarif_malzeme_iliski tablosundan silme işlemi
                data.DeleteTarifMalzemeIliskiByTarifID(tarifID);

                // TarifID ile tarif tablosundan silme işlemi
                data.DeleteTarifByTarifID(tarifID);

                // Tarife ait malzemeler ve tarif silindikten sonra ListBox'tan tarifi sil
                listBox1.Items.Remove(listBox1.SelectedItem);

                MessageBox.Show("Tarif ve ilişkili malzemeler silindi.");
            }
            else
            {
                MessageBox.Show("Tarif bulunamadı.");
            }
        }


        private void Form3_Load(object sender, EventArgs e)
        {
            // Data sınıfı ile tarif tablosundan verileri çek
            Data.Data data = new Data.Data();
            List<string> tarifAdlari = data.GetAllTarifAdlari(); // Tarif tablosundan TarifAdi sütununu çeken fonksiyon

            // ListBox'a tarif adlarını ekle
            foreach (string tarifAdi in tarifAdlari)
            {
                listBox1.Items.Add(tarifAdi);
            }
        }

    }
}
