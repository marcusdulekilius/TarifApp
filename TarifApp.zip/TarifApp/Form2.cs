﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TarifApp
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_2_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void checkedListBox2_1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
        //Bu satırı bağlamak için kullanırız
        private Image uploadedImage;
        private void pictureBox2_1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            // Sadece JPG ve PNG
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png";

            // Kullanıcı dosya seçimini tamamladığında
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Seçilen dosyayı PictureBox içinde gösteriyoruz
                pictureBox2_1.Image = Image.FromFile(openFileDialog.FileName);
                uploadedImage = pictureBox2_1.Image;
            }
        }

        private void button2_1_Click(object sender, EventArgs e)
        {
            if (uploadedImage != null)
            {
                // Resmi eklemek için gerekli işlemleri yapın
                MessageBox.Show("Resim yüklendi.");
            }
            else
            {
                MessageBox.Show("Lütfen bir resim yükleyin.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
