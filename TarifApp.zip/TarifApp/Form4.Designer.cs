﻿namespace TarifApp
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            textBox4_1 = new TextBox();
            panel4_1 = new Panel();
            listBox4_1 = new ListBox();
            panel4_2 = new Panel();
            label4_1 = new Label();
            panel4_1.SuspendLayout();
            panel4_2.SuspendLayout();
            SuspendLayout();
            // 
            // textBox4_1
            // 
            textBox4_1.Location = new Point(28, 22);
            textBox4_1.Name = "textBox4_1";
            textBox4_1.Size = new Size(198, 23);
            textBox4_1.TabIndex = 0;
            textBox4_1.TextChanged += textBox4_1_TextChanged;
            // 
            // panel4_1
            // 
            panel4_1.Controls.Add(listBox4_1);
            panel4_1.Controls.Add(textBox4_1);
            panel4_1.Dock = DockStyle.Left;
            panel4_1.Location = new Point(0, 0);
            panel4_1.Name = "panel4_1";
            panel4_1.Size = new Size(257, 534);
            panel4_1.TabIndex = 1;
            // 
            // listBox4_1
            // 
            listBox4_1.BackColor = Color.OliveDrab;
            listBox4_1.FormattingEnabled = true;
            listBox4_1.ItemHeight = 15;
            listBox4_1.Location = new Point(12, 70);
            listBox4_1.Name = "listBox4_1";
            listBox4_1.Size = new Size(228, 439);
            listBox4_1.TabIndex = 1;
            // 
            // panel4_2
            // 
            panel4_2.BackColor = Color.SeaGreen;
            panel4_2.Controls.Add(label4_1);
            panel4_2.Dock = DockStyle.Fill;
            panel4_2.Location = new Point(257, 0);
            panel4_2.Name = "panel4_2";
            panel4_2.Size = new Size(553, 534);
            panel4_2.TabIndex = 2;
            panel4_2.Paint += panel4_2_Paint;
            // 
            // label4_1
            // 
            label4_1.AutoSize = true;
            label4_1.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 162);
            label4_1.Location = new Point(202, 18);
            label4_1.Name = "label4_1";
            label4_1.Size = new Size(130, 24);
            label4_1.TabIndex = 0;
            label4_1.Text = "Tarif Bilgileri";
            // 
            // Form4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSeaGreen;
            ClientSize = new Size(810, 534);
            Controls.Add(panel4_2);
            Controls.Add(panel4_1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "Form4";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Güncelle";
            Load += Form4_Load;
            panel4_1.ResumeLayout(false);
            panel4_1.PerformLayout();
            panel4_2.ResumeLayout(false);
            panel4_2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TextBox textBox4_1;
        private Panel panel4_1;
        private ListBox listBox4_1;
        private Panel panel4_2;
        private Label label4_1;
    }
}