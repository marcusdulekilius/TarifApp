﻿namespace TarifApp
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            textBox2_1 = new TextBox();
            textBox2_2 = new TextBox();
            label2_1 = new Label();
            label2_8 = new Label();
            label2_2 = new Label();
            label2_9 = new Label();
            comboBox2_1 = new ComboBox();
            checkedListBox2_1 = new CheckedListBox();
            button2_2 = new Button();
            label2_3 = new Label();
            panel1 = new Panel();
            label2_7 = new Label();
            button2_1 = new Button();
            pictureBox2_1 = new PictureBox();
            label2_6 = new Label();
            comboBox2 = new ComboBox();
            comboBox1 = new ComboBox();
            label2_5 = new Label();
            label2_4 = new Label();
            panel2 = new Panel();
            button1 = new Button();
            label2_11 = new Label();
            richTextBox1 = new RichTextBox();
            label2_10 = new Label();
            openFileDialog1 = new OpenFileDialog();
            panel3 = new Panel();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2_1).BeginInit();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // textBox2_1
            // 
            textBox2_1.Location = new Point(12, 69);
            textBox2_1.Name = "textBox2_1";
            textBox2_1.Size = new Size(235, 23);
            textBox2_1.TabIndex = 0;
            // 
            // textBox2_2
            // 
            textBox2_2.Location = new Point(321, 356);
            textBox2_2.Name = "textBox2_2";
            textBox2_2.Size = new Size(175, 23);
            textBox2_2.TabIndex = 1;
            // 
            // label2_1
            // 
            label2_1.AutoSize = true;
            label2_1.Font = new Font("Trebuchet MS", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label2_1.Location = new Point(74, 31);
            label2_1.Name = "label2_1";
            label2_1.Size = new Size(105, 20);
            label2_1.TabIndex = 2;
            label2_1.Text = "Tarifinizin Adı";
            label2_1.Click += label1_Click;
            // 
            // label2_8
            // 
            label2_8.AutoSize = true;
            label2_8.Font = new Font("Trebuchet MS", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label2_8.Location = new Point(321, 31);
            label2_8.Name = "label2_8";
            label2_8.Size = new Size(169, 20);
            label2_8.TabIndex = 3;
            label2_8.Text = "Tarifinizin Malzemeleri\r\n";
            // 
            // label2_2
            // 
            label2_2.AutoSize = true;
            label2_2.Font = new Font("Trebuchet MS", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label2_2.Location = new Point(51, 121);
            label2_2.Name = "label2_2";
            label2_2.Size = new Size(151, 20);
            label2_2.TabIndex = 4;
            label2_2.Text = "Tarifinizin Kategorisi";
            // 
            // label2_9
            // 
            label2_9.AutoSize = true;
            label2_9.Font = new Font("Trebuchet MS", 8.25F, FontStyle.Italic, GraphicsUnit.Point, 162);
            label2_9.Location = new Point(338, 281);
            label2_9.Name = "label2_9";
            label2_9.Size = new Size(132, 48);
            label2_9.TabIndex = 5;
            label2_9.Text = "Listede olmayan bir ürün\r\nvarsa buraya yazarak\r\nekleyebilirsiniz.";
            label2_9.Click += label4_Click;
            // 
            // comboBox2_1
            // 
            comboBox2_1.FormattingEnabled = true;
            comboBox2_1.Items.AddRange(new object[] { "Ana Yemek", "Çorba", "Tatlı", "Salata", "Atıştırmalık" });
            comboBox2_1.Location = new Point(51, 157);
            comboBox2_1.Name = "comboBox2_1";
            comboBox2_1.Size = new Size(157, 23);
            comboBox2_1.TabIndex = 6;
            comboBox2_1.Text = "Seçiniz";
            // 
            // checkedListBox2_1
            // 
            checkedListBox2_1.BackColor = Color.LightSeaGreen;
            checkedListBox2_1.CheckOnClick = true;
            checkedListBox2_1.FormattingEnabled = true;
            checkedListBox2_1.Items.AddRange(new object[] { "Çikolata", "Muz", "Soğan", "Su", "Şeker", "Tuz", "Un", "Yağ", "Yumurta" });
            checkedListBox2_1.Location = new Point(321, 69);
            checkedListBox2_1.Name = "checkedListBox2_1";
            checkedListBox2_1.Size = new Size(175, 184);
            checkedListBox2_1.Sorted = true;
            checkedListBox2_1.TabIndex = 7;
            checkedListBox2_1.SelectedIndexChanged += checkedListBox2_1_SelectedIndexChanged;
            // 
            // button2_2
            // 
            button2_2.Location = new Point(321, 410);
            button2_2.Name = "button2_2";
            button2_2.Size = new Size(175, 23);
            button2_2.TabIndex = 9;
            button2_2.Text = "Ekle";
            button2_2.UseVisualStyleBackColor = true;
            button2_2.Click += button2_2_Click;
            // 
            // label2_3
            // 
            label2_3.AutoSize = true;
            label2_3.Font = new Font("Trebuchet MS", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label2_3.Location = new Point(26, 217);
            label2_3.Name = "label2_3";
            label2_3.Size = new Size(208, 20);
            label2_3.TabIndex = 11;
            label2_3.Text = "Tarifinizin Hazırlanma Süresi";
            // 
            // panel1
            // 
            panel1.BackColor = Color.LightPink;
            panel1.Controls.Add(label2_7);
            panel1.Controls.Add(button2_1);
            panel1.Controls.Add(pictureBox2_1);
            panel1.Controls.Add(label2_6);
            panel1.Controls.Add(comboBox2);
            panel1.Controls.Add(comboBox1);
            panel1.Controls.Add(label2_5);
            panel1.Controls.Add(label2_4);
            panel1.Controls.Add(label2_3);
            panel1.Controls.Add(label2_1);
            panel1.Controls.Add(textBox2_1);
            panel1.Controls.Add(comboBox2_1);
            panel1.Controls.Add(label2_2);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(263, 534);
            panel1.TabIndex = 12;
            // 
            // label2_7
            // 
            label2_7.AutoSize = true;
            label2_7.Font = new Font("Trebuchet MS", 8.25F, FontStyle.Italic, GraphicsUnit.Point, 162);
            label2_7.Location = new Point(74, 356);
            label2_7.Name = "label2_7";
            label2_7.Size = new Size(112, 16);
            label2_7.TabIndex = 19;
            label2_7.Text = "PNG veya JPG dosyası";
            // 
            // button2_1
            // 
            button2_1.Location = new Point(51, 453);
            button2_1.Name = "button2_1";
            button2_1.Size = new Size(157, 39);
            button2_1.TabIndex = 18;
            button2_1.Text = "Ekle";
            button2_1.UseVisualStyleBackColor = true;
            button2_1.Click += button2_1_Click;
            // 
            // pictureBox2_1
            // 
            pictureBox2_1.BackColor = Color.LightSeaGreen;
            pictureBox2_1.InitialImage = Properties.Resources.Upload;
            pictureBox2_1.Location = new Point(51, 375);
            pictureBox2_1.Name = "pictureBox2_1";
            pictureBox2_1.Size = new Size(157, 72);
            pictureBox2_1.TabIndex = 17;
            pictureBox2_1.TabStop = false;
            pictureBox2_1.Click += pictureBox2_1_Click;
            // 
            // label2_6
            // 
            label2_6.AutoSize = true;
            label2_6.Font = new Font("Trebuchet MS", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label2_6.Location = new Point(71, 327);
            label2_6.Name = "label2_6";
            label2_6.Size = new Size(124, 20);
            label2_6.TabIndex = 16;
            label2_6.Text = "Tarifinizin Resmi";
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59" });
            comboBox2.Location = new Point(138, 255);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(57, 23);
            comboBox2.TabIndex = 15;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" });
            comboBox1.Location = new Point(45, 255);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(57, 23);
            comboBox1.TabIndex = 14;
            // 
            // label2_5
            // 
            label2_5.AutoSize = true;
            label2_5.Location = new Point(154, 281);
            label2_5.Name = "label2_5";
            label2_5.Size = new Size(41, 15);
            label2_5.TabIndex = 13;
            label2_5.Text = "dakika";
            // 
            // label2_4
            // 
            label2_4.AutoSize = true;
            label2_4.Location = new Point(74, 281);
            label2_4.Name = "label2_4";
            label2_4.Size = new Size(28, 15);
            label2_4.TabIndex = 12;
            label2_4.Text = "saat";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Plum;
            panel2.Controls.Add(button1);
            panel2.Controls.Add(label2_11);
            panel2.Controls.Add(richTextBox1);
            panel2.Controls.Add(label2_10);
            panel2.Dock = DockStyle.Right;
            panel2.Location = new Point(549, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(261, 534);
            panel2.TabIndex = 13;
            // 
            // button1
            // 
            button1.BackColor = Color.SkyBlue;
            button1.Dock = DockStyle.Bottom;
            button1.Font = new Font("Trebuchet MS", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 162);
            button1.Location = new Point(0, 470);
            button1.Name = "button1";
            button1.Size = new Size(261, 64);
            button1.TabIndex = 7;
            button1.Text = "TARİF EKLE";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label2_11
            // 
            label2_11.AutoSize = true;
            label2_11.Font = new Font("Trebuchet MS", 8.25F, FontStyle.Italic, GraphicsUnit.Point, 162);
            label2_11.Location = new Point(46, 60);
            label2_11.Name = "label2_11";
            label2_11.Size = new Size(152, 32);
            label2_11.TabIndex = 6;
            label2_11.Text = "Lütfen her aşama sonrasında\r\nbir alt satıra geçiniz.";
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(15, 110);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(234, 313);
            richTextBox1.TabIndex = 5;
            richTextBox1.Text = "\n";
            richTextBox1.TextChanged += richTextBox1_TextChanged;
            // 
            // label2_10
            // 
            label2_10.AutoSize = true;
            label2_10.Font = new Font("Trebuchet MS", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label2_10.Location = new Point(46, 31);
            label2_10.Name = "label2_10";
            label2_10.Size = new Size(155, 20);
            label2_10.TabIndex = 4;
            label2_10.Text = "Tarifinizin Talimatları";
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // panel3
            // 
            panel3.Controls.Add(label2_8);
            panel3.Controls.Add(checkedListBox2_1);
            panel3.Controls.Add(button2_2);
            panel3.Controls.Add(label2_9);
            panel3.Controls.Add(textBox2_2);
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(810, 534);
            panel3.TabIndex = 14;
            panel3.Paint += panel3_Paint;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PaleVioletRed;
            ClientSize = new Size(810, 534);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(panel3);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "Form2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Tarif Ekle";
            Load += Form2_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2_1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TextBox textBox2_1;
        private TextBox textBox2_2;
        private Label label2_1;
        private Label label2_8;
        private Label label2_2;
        private Label label2_9;
        private ComboBox comboBox2_1;
        private CheckedListBox checkedListBox2_1;
        private Button button2_2;
        private Label label2_3;
        private Panel panel1;
        private Label label2_5;
        private Label label2_4;
        private Panel panel2;
        private RichTextBox richTextBox1;
        private Label label2_10;
        private Label label2_11;
        private Label label2_6;
        private Button button2_1;
        private PictureBox pictureBox2_1;
        private OpenFileDialog openFileDialog1;
        private Label label2_7;
        private Panel panel3;
        private Button button1;
        private ComboBox comboBox2;
        private ComboBox comboBox1;
    }
}